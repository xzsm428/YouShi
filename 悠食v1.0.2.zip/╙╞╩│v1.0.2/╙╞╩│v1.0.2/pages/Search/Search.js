// Pages/Search/Search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    already: 0,
    metabolism: 0,
    list:[],
    content:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      metabolism: getApp().globalData.metabolism,
      already:getApp().globalData.already
    })
  },

  Search:function (res) {
    console.log(res.detail.value)
    this.setData({
      content:res.detail.value
    })
    wx.cloud.database().collection('food')
      .where({//模糊搜索
        name: wx.cloud.database().RegExp({
          regexp: res.detail.value, //要搜索的词
          options: 'i' //不区分大小写
        })
      })
      .get()
      .then(res => { //请求成功
        console.log('模糊搜索食品列表请求成功',res.data)
        this.setData({
          list:res.data
        })
      })
      .catch(err => { //请求失败
        console.log('模糊搜索食品列表请求失败',err)
      })
  },
  addfood: function (res) {
    var that = res
    wx.showModal({
      title: '添加',
      editable: true,
      placeholderText: '请输入克数',
      success: (res) => {
        if (res.confirm) {
          if (!(/^\d+(\.\d+)?$/.test(res.content))) {
            wx.showToast({
              title: '输入格式错误',
              duration: 2000,
              icon: 'none'
            });
          }
          else {
            this.setData({
              already: Number((this.data.already + Number(res.content) * Number(that.currentTarget.dataset.cal) / 100).toFixed(2))
            })
            getApp().globalData.already = this.data.already
            getApp().globalData.already_data[getApp().globalData.already_data.length]={name:that.currentTarget.dataset.name,
            amount:res.content+'克',
          cal:Number((Number(res.content) * Number(that.currentTarget.dataset.cal) / 100).toFixed(2))};
              console.log(getApp().globalData.already_data)
              wx.showToast({
                title: '添加成功',
                duration: 1000,
                icon: 'none'
                });
          }
        }
      }
    })
  },
  upload: function () {
    var that = this
    wx.showModal({
      title: '提示',
      content: '您确定已完成食物的选取？',
      success(res) {
        if (res.confirm){
        wx.cloud.database().collection('history')
          .where({//查询是否有用户当天的历史数据
            _openid: getApp().globalData.openid,
            date: getApp().globalData.date
          })
          .get()
          .then(res => { //请求成功
            console.log('寻找数据请求成功', res.data)
            if (res.data.length == 0) {
              that.data.judge = 1
              console.log(that.data.judge)
            }
            else {
              that.data.judge = 2
              that.data._id = res.data[0]._id
              console.log(res.data[0]._id)
            }
            if (that.data.judge == 1) {
              wx.cloud.database().collection('history')
                .add({//添加数据
                  data: {
                    cal: that.data.already,
                    date: getApp().globalData.date
                  }
                })
                .then(res => {
                  console.log('添加成功', res)
                  wx.showToast({
                    title: '添加成功',
                    duration: 2000,
                    icon: 'none'
                    });
                })
                .catch(res => {
                  wx.showToast({
                    title: '添加失败',
                    duration: 2000,
                    icon: 'none'
                    });
                  console.log('添加失败', res)
                })
            }
            else {
              wx.cloud.database().collection('history')
                .doc(that.data._id)
                .update({//更新数据
                  data: {
                    cal: that.data.already,
                  }
                })
                .then(res => {
                  console.log('更新成功', res)
                  wx.showToast({
                    title: '更新成功',
                    duration: 2000,
                    icon: 'none'
                    });
                })
                .catch(res => {
                  console.log('更新失败', res)
                  wx.showToast({
                    title: '更新失败',
                    duration: 2000,
                    icon: 'none'
                    });
                })
            }
          })
      }
    }
    })
  },
  Add: function (res) {
    wx.showModal({
      title: '添加',
      editable: true,
      placeholderText: '请输入摄入热量',
      success: (res) => {
        if (res.confirm) {
          if (!(/^\d+(\.\d+)?$/.test(res.content))) {
            wx.showToast({
              title: '输入格式错误',
              duration: 2000,
              icon: 'none'
            });
          }
          else {
            var tmp=this.data.already+Number(res.content)
            tmp=Number(tmp.toFixed(2))
            this.setData({
              already: tmp
            })
            getApp().globalData.already = this.data.already
            getApp().globalData.already_data[getApp().globalData.already_data.length]={name:"手动添加",
          amount:"",
        cal:res.content};
            console.log(getApp().globalData.already_data)
            wx.showToast({
              title: '添加成功',
              duration: 1000,
              icon: 'none'
              });
          }
        }
      }
    })
  },
  ToAlready:function(){
    wx.navigateTo({
      url: '/pages/already/already',
    })
  },
})