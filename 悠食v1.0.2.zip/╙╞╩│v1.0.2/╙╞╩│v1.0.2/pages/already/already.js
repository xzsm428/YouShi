// pages/already/already.js
Page({

  data: {
    already_data: []
  },

  onShow() {
    this.setData({
      already_data: getApp().globalData.already_data
    })
    console.log(this.data.already_data)
  },

  Del: function (e) {
    var index = e.currentTarget.dataset.index
    var that=this
    console.log(index)
    wx.showModal({
      title: '提示',
      content: '是否要删除该条数据',
      success(res) {
        if (res.confirm) {
          getApp().globalData.already=Number((getApp().globalData.already-that.data.already_data[index].cal).toFixed(2))
          that.data.already_data.splice(index, 1)
          that.setData({
            already_data: that.data.already_data
          })
          console.log(that.data.already_data)
          getApp().globalData.already_data = that.data.already_data;
          wx.showToast({
            title: '删除成功',
            duration: 1000,
            icon: 'none'
            });
        }
      }
    })
  }
})