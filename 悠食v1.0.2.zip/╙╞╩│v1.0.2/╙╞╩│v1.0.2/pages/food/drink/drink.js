Page({
  data: {
    list: [],
    already: 0,
    metabolism: 0,
  },
  onLoad() {
    this.getList()
    this.setData({
      metabolism: getApp().globalData.metabolism,
      already: getApp().globalData.already
    })
  },
  onShow(){
    this.setData({
      metabolism: getApp().globalData.metabolism,
      already: getApp().globalData.already
    })
  },
  async getList() {
    let count  =await wx.cloud.database().collection('food')
    .where({//条件查询
      class: '饮品'
    })
    .count()
    count = count.total
    console.log('食品数据总个数', count)
    let all = []
    for (let i = 0;i < count;i += 20) {
      let food_part = await wx.cloud.database().collection('food')
      .where({//条件查询
        class: '饮品'
      })
      .skip(i)
      .get()
      all = all.concat(food_part.data)
      this.setData({
        list: all
      })
    }
  },

  addfood: function (res) {
    var that = res
    wx.showModal({
      title: '添加',
      editable: true,
      placeholderText: '请输入克数',
      success: (res) => {
        if (res.confirm) {
          if (!(/^\d+(\.\d+)?$/.test(res.content))) {
            wx.showToast({
              title: '输入格式错误',
              duration: 2000,
              icon: 'none'
            });
          }
          else {
            this.setData({
              already: Number((this.data.already + Number(res.content) * Number(that.currentTarget.dataset.cal) / 100).toFixed(2))
            })
            getApp().globalData.already = this.data.already
            getApp().globalData.already_data[getApp().globalData.already_data.length]={name:that.currentTarget.dataset.name,
            amount:res.content+'克',
            cal:Number((Number(res.content) * Number(that.currentTarget.dataset.cal) / 100).toFixed(2))};
              console.log(getApp().globalData.already_data)
              wx.showToast({
                title: '添加成功',
                duration: 1000,
                icon: 'none'
                });
          }
        }
      }
    })
  },
  upload: function () {
    var that = this
    wx.showModal({
      title: '提示',
      content: '您确定已完成食物的选取？',
      success(res) {
        if (res.confirm){
        wx.cloud.database().collection('history')
          .where({//查询是否有用户当天的历史数据
            _openid: getApp().globalData.openid,
            date: getApp().globalData.date
          })
          .get()
          .then(res => { //请求成功
            console.log('寻找数据请求成功', res.data)
            if (res.data.length == 0) {
              that.data.judge = 1
              console.log(that.data.judge)
            }
            else {
              that.data.judge = 2
              that.data._id = res.data[0]._id
              console.log(res.data[0]._id)
            }
            if (that.data.judge == 1) {
              wx.cloud.database().collection('history')
                .add({//添加数据
                  data: {
                    cal: that.data.already,
                    date: getApp().globalData.date
                  }
                })
                .then(res => {
                  console.log('添加成功', res)
                  wx.showToast({
                    title: '添加成功',
                    duration: 2000,
                    icon: 'none'
                    });
                })
                .catch(res => {
                  wx.showToast({
                    title: '添加失败',
                    duration: 2000,
                    icon: 'none'
                    });
                  console.log('添加失败', res)
                })
            }
            else {
              wx.cloud.database().collection('history')
                .doc(that.data._id)
                .update({//更新数据
                  data: {
                    cal: that.data.already,
                  }
                })
                .then(res => {
                  console.log('更新成功', res)
                  wx.showToast({
                    title: '更新成功',
                    duration: 2000,
                    icon: 'none'
                    });
                })
                .catch(res => {
                  console.log('更新失败', res)
                  wx.showToast({
                    title: '更新失败',
                    duration: 2000,
                    icon: 'none'
                    });
                })
            }
          })
      }
    }
    })
  },

  // 搜索
  Add: function (res) {
    wx.showModal({
      title: '添加',
      editable: true,
      placeholderText: '请输入摄入热量',
      success: (res) => {
        if (res.confirm) {
          if (!(/^\d+(\.\d+)?$/.test(res.content))) {
            wx.showToast({
              title: '输入格式错误',
              duration: 2000,
              icon: 'none'
            });
          }
          else {
            var tmp=this.data.already+Number(res.content)
            tmp=Number(tmp.toFixed(2))
            this.setData({
              already: tmp
            })
            getApp().globalData.already = this.data.already
            getApp().globalData.already_data[getApp().globalData.already_data.length]={name:"手动添加",
          amount:"",
        cal:res.content};
            console.log(getApp().globalData.already_data)
            wx.showToast({
              title: '添加成功',
              duration: 1000,
              icon: 'none'
              });
          }
        }
      }
    })
  },
  ToSearch: function () {
    wx.navigateTo({
      url: '/pages/Search/Search'
    })
  },

  ToAlready:function(){
    wx.navigateTo({
      url: '/pages/already/already',
    })
  },
})