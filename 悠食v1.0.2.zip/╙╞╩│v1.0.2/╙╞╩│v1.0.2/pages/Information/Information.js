Page({
  data:{
    list:[],
    headURL: ""
  },
  onLoad(){
    this.setData({
      headURL: getApp().globalData.userInfo.avatarUrl
    })
    wx.cloud.database().collection('pri_inf')
    .where({//查询用户的基本信息
      _openid: getApp().globalData.openid
    })
    .get()
    .then(res => {
      console.log('用户基本信息请求成功',res)
      this.setData({
        list: res.data
      })
    })
    .catch(res =>{
      console.log('用户基本信息请求失败',res)
    })
  },
  ToCalculate: function (e) {
    let height=e.currentTarget.dataset.height;
    let weight=e.currentTarget.dataset.weight;
    let age=e.currentTarget.dataset.age;
    let sex=e.currentTarget.dataset.sex;
    wx.reLaunch({
      url: '/pages/Calculate/Calculate?height='+height+'&weight='+weight+'&age='+String(age)+'&sex='+sex
    })
  },
})
