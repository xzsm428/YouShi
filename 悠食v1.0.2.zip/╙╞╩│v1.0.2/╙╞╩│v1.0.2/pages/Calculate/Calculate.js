// pages/Calculate/Calculate.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sex: ['男', '女'],
    index: 0,
    height: "",
    weight: "",
    age: "",
    metabolism: 0,
    judge: 0,
    _id: ""
  },

  onLoad(option) {
    if (option.sex == '女') {
      this.setData({
        index: 1
      })
    }
    if (option.height != undefined) {
      this.setData({
        height: option.height,
        weight: option.weight,
        age: option.age
      })
    }
    console.log(this.data.height)
    console.log(this.data.weight)
    console.log(this.data.age)
    console.log(this.data.index)
    //获取用户的基本代谢水平（如果有）
    wx.cloud.database().collection('pri_inf')
      .where({//查询是否有用户的个人数据
        _openid: getApp().globalData.openid
      })
      .get()
      .then(res => { //请求成功
        console.log('寻找个人信息请求成功', res.data)
        getApp().globalData.metabolism = res.data[0].metabolism * 1.2
        getApp().globalData.metabolism = Number((getApp().globalData.metabolism).toFixed(2))
        console.log('用户原本的基本代谢水平', getApp().globalData.metabolism)
      })
  },

  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },

  heightInput: function (e) {
    this.data.height = e.detail.value
  },

  weightInput: function (e) {
    this.data.weight = e.detail.value
  },

  ageInput: function (e) {
    this.data.age = e.detail.value
  },

  calculate: function (e) {
    var that = this
    console.log(that.data.height)
    console.log(that.data.weight)
    console.log(that.data.age)
    if (that.data.height == "") {
      wx.showToast({
        title: '未输入身高',
        duration: 2000,
        icon: 'none'
      });
    }
    else if (that.data.weight == "") {
      wx.showToast({
        title: '未输入体重',
        duration: 2000,
        icon: 'none'
      });
    }
    else if (that.data.age == "") {
      wx.showToast({
        title: '未输入年龄',
        duration: 2000,
        icon: 'none'
      });
    }
    else if (!(/^\d+(\.\d+)?$/.test(that.data.height))) {
      wx.showToast({
        title: '身高格式不对',
        duration: 2000,
        icon: 'none'
      });
    }
    else if (!(/^\d+(\.\d+)?$/.test(that.data.weight))) {
      wx.showToast({
        title: '体重格式不对',
        duration: 2000,
        icon: 'none'
      });
    }
    else {
      if (this.data.index == 0) {
        this.data.metabolism = 67 + 13.73 * Number(this.data.weight) + 5 * Number(this.data.height) - 6.9 * Number(this.data.age)
        this.data.metabolism = Number((this.data.metabolism).toFixed(2))
      }
      else {
        this.data.metabolism = 661 + 9.6 * Number(this.data.weight) + 1.72 * Number(this.data.height) - 4.7 * Number(this.data.age)
        this.data.metabolism = Number((this.data.metabolism).toFixed(2))
      }
      wx.showModal({
        title: '结果',
        content: '您一天的基础代谢为' + String(this.data.metabolism) + '千卡\r\n是否更新个人数据？',
        success(res) {
          if (res.confirm) {
            getApp().globalData.metabolism = Number((that.data.metabolism * 1.2).toFixed(2))
            console.log('用户点击确定')//写数据库
            console.log(getApp().globalData.openid)
            wx.cloud.database().collection('pri_inf')
              .where({//查询是否有用户的个人数据
                _openid: getApp().globalData.openid
              })
              .get()
              .then(res => { //请求成功
                console.log('寻找数据请求成功', res.data)
                if (res.data.length == 0) {
                  that.data.judge = 1
                  console.log(that.data.judge)
                }
                else {
                  that.data.judge = 2
                  that.data._id = res.data[0]._id
                  console.log(res.data[0]._id)
                }
                if (that.data.judge == 1) {
                  wx.cloud.database().collection('pri_inf')
                    .add({//添加数据
                      data: {
                        height: that.data.height,
                        weight: that.data.weight,
                        age: that.data.age,
                        sex: that.data.sex[that.data.index],
                        metabolism: that.data.metabolism
                      }
                    })
                    .then(res => {
                      console.log('添加成功', res)
                    })
                    .catch(res => {
                      console.log('添加失败', res)
                    })
                }
                else {
                  wx.cloud.database().collection('pri_inf')
                    .doc(that.data._id)
                    .update({//更新数据
                      data: {
                        height: that.data.height,
                        weight: that.data.weight,
                        age: that.data.age,
                        sex: that.data.sex[that.data.index],
                        metabolism: that.data.metabolism
                      }
                    })
                    .then(res => {
                      console.log('更新成功', res)
                    })
                    .catch(res => {
                      console.log('更新失败', res)
                    })
                }
              })
              wx.showToast({
                title: '更新成功',
                duration: 1000,
                icon: 'none'
                });
          }
        }
      })
    }
  },

  ToFoodSelect: function () {
    wx.redirectTo({
      url: '/pages/foodSelect/foodSelect'
    })
  },

  ToPersonalData: function () {
    wx.redirectTo({
      url: '/pages/PersonalData/PersonalData'
    })
  },
})