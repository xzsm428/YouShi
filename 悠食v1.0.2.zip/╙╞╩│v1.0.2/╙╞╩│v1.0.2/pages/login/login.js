Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUseGetUserProfile: false,
  },
  onLoad() {
    if (wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true
      })
    }
    else {
      wx.redirectTo({
        url: '/pages/Calculate/Calculate'
      })
    }
  },
  getUserProfile(e) {
    wx.getUserProfile({
      desc: '用于获取用户的头像，昵称',
      success: (res) => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
        getApp().globalData.userInfo=res.userInfo
        wx.redirectTo({
          url: '/pages/Calculate/Calculate'
        })
      }
    })
  }
})