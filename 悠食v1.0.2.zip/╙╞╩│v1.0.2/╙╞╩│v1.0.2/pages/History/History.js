Page({
  data:{
    list:[]
  },
  async onLoad(){
    let count  =await wx.cloud.database().collection('history')
    .where({//条件查询
      _openid: getApp().globalData.openid
    })
    .count()
    count = count.total
    console.log('历史数据总数', count)
    let all = []
    for (let i = 0;i < count;i += 20) {
      let food_part = await wx.cloud.database().collection('history')
      .where({//条件查询
        _openid: getApp().globalData.openid
      })
      .skip(i)
      .get()
      all = all.concat(food_part.data)
      this.setData({
        list: all 
      })
    }
  }
})
