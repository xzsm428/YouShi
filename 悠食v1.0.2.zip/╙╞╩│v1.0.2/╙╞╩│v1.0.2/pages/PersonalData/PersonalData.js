// pages/PersonalData/PersonalData.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nickName: "",
    headURL: ""
  },

  onLoad: function () {
    this.setData({
      nickName: getApp().globalData.userInfo.nickName,
      headURL: getApp().globalData.userInfo.avatarUrl
    })
  },
  ToFoodSelect: function () {
    wx.redirectTo({
      url: '/pages/foodSelect/foodSelect'
    })
  },

  ToCalculate: function () {
    wx.redirectTo({
      url: '/pages/Calculate/Calculate'
    })
  },

  ToInformation:function(){
    wx.navigateTo({
      url: '/pages/Information/Information',
    })
  },

  ToHistory:function(){
    wx.navigateTo({
      url: '/pages/History/History',
    })
  }
})