// app.js
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    wx.cloud.init(
      {
        env:'xiao-qin-9g35gnjfeaa45d18'
      }
    )
    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        this.getOpenid()
      }
    })
  },

  //获取用户的openid
  getOpenid() {  
    let that = this;
    wx.cloud.callFunction({   
      name: 'getOpenid',   
      complete: res => {       
        console.log('云函数获取到的openid: ', res.result.openid)    
        var openid = res.result.openid;
        this.globalData.openid = openid
     }
    })
   },


  globalData: {
    userInfo: null,
    metabolism:0,
    already:0,
    already_data:[],
    openid:"",
    date: new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + new Date().getDate()
  }
})
